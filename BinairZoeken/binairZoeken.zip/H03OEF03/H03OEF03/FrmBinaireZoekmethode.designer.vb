﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmBinaireZoekmethode
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lstArray = New System.Windows.Forms.ListBox()
        Me.btnZoeken = New System.Windows.Forms.Button()
        Me.btnSluiten = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lstArray
        '
        Me.lstArray.FormattingEnabled = True
        Me.lstArray.ItemHeight = 16
        Me.lstArray.Location = New System.Drawing.Point(13, 13)
        Me.lstArray.Name = "lstArray"
        Me.lstArray.Size = New System.Drawing.Size(249, 468)
        Me.lstArray.TabIndex = 0
        '
        'btnZoeken
        '
        Me.btnZoeken.Location = New System.Drawing.Point(302, 13)
        Me.btnZoeken.Name = "btnZoeken"
        Me.btnZoeken.Size = New System.Drawing.Size(116, 45)
        Me.btnZoeken.TabIndex = 1
        Me.btnZoeken.Text = "&Zoeken"
        Me.btnZoeken.UseVisualStyleBackColor = True
        '
        'btnSluiten
        '
        Me.btnSluiten.Location = New System.Drawing.Point(302, 73)
        Me.btnSluiten.Name = "btnSluiten"
        Me.btnSluiten.Size = New System.Drawing.Size(116, 45)
        Me.btnSluiten.TabIndex = 1
        Me.btnSluiten.Text = "&Sluiten"
        Me.btnSluiten.UseVisualStyleBackColor = True
        '
        'FrmBinaireZoekmethode
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(449, 495)
        Me.Controls.Add(Me.btnSluiten)
        Me.Controls.Add(Me.btnZoeken)
        Me.Controls.Add(Me.lstArray)
        Me.Name = "FrmBinaireZoekmethode"
        Me.Text = "Binaire zoekmethode"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents lstArray As System.Windows.Forms.ListBox
    Friend WithEvents btnZoeken As System.Windows.Forms.Button
    Friend WithEvents btnSluiten As System.Windows.Forms.Button

End Class
