﻿Public Class FrmBinaireZoekmethode
    Private getal() As Short = New Short(200) {}

    Private Sub FrmBinaireZoekmethode_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Genereer de array
        GenereerGetallen(getal)
        ' Sorteer de array
        Array.Sort(getal)
        ' Toon array
        ToonGetallenInLijst(getal)
    End Sub

    Private Sub GenereerGetallen(ByRef getal As Short())
        ' De procedure genereert getallen tussen 1 en 1000
        ' en plaatst deze in de array getal.
        Dim i As Integer
        Dim willekeurig As New System.Random()

        For i = 0 To getal.GetUpperBound(0)
            getal(i) = CShort(willekeurig.Next(1000)) + 1S
        Next
    End Sub

    Private Sub ToonGetallenInLijst(ByVal getal() As Short)
        ' Declaratie variabelen
        Dim g As Short
        ' Lijst nog leegmaken
        lstArray.Items.Clear()
        ' Opvullen array
        For Each g In getal
            lstArray.Items.Add(g)
        Next
    End Sub

    Private Function BinaireZoekmethode(ByVal a As Short(), ByVal teZoeken As Short, ByRef teller As Integer) As Short
        ' Declaratie variabelen
        Dim b, e, m As Integer
        Dim gevonden As Boolean
        b = 0
        e = a.Length - 1
        While b <= e And Not gevonden
            m = (b + e) \ 2
            If teZoeken > a(m) Then
                b = m + 1
            Else
                If teZoeken < a(m) Then
                    e = m - 1
                Else
                    gevonden = True
                    Return CType(m, Short)
                End If
            End If
            teller += 1
        End While
        Return 0
    End Function

    

    Private Sub btnZoeken_Click(sender As Object, e As EventArgs) Handles btnZoeken.Click
        ' Declaratie variabelen
        Dim teZoeken As Short
        Dim indexGevonden As Short
        Dim boodschap As String
        Dim teller As Integer
        ' Zoek een waarde in de array
        teZoeken = CType(InputBox("Geef een te zoeken waarde:", "Zoeken naar een waarde"), Short)
        indexGevonden = BinaireZoekmethode(getal, teZoeken, teller)

        ' Toon het resultaat
        If indexGevonden > getal.GetUpperBound(0) Or indexGevonden < -(getal.GetUpperBound(0)) Then
            boodschap = "De waarde is groter dan alle waarden in de rij."
            MessageBox.Show(boodschap, "Resultaat", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Exit Sub
        End If

        Select Case indexGevonden
            Case Is < 0
                boodschap = "De waarde is niet gevonden. De volgende waarde, " & getal(-(indexGevonden + 1)) & " komt voor bij index " _
                    & (-(indexGevonden + 1)).ToString & "."
            Case Else
                boodschap = "De waarde is gevonden bij index " & indexGevonden.ToString & ". Er is " & teller.ToString & " keer achter gezocht."
        End Select

        MessageBox.Show(boodschap, "Resultaat", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Sub btnSluiten_Click(sender As Object, e As EventArgs) Handles btnSluiten.Click
        Me.Close()
    End Sub
End Class
