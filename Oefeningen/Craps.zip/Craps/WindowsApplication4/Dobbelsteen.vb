﻿Public Class Dobbelsteen


    Private getal As Random

    Public Sub New()
        getal = New Random()
    End Sub

    Public Function Gooi() As Integer
        Return getal.Next(1, 6)
    End Function

End Class
