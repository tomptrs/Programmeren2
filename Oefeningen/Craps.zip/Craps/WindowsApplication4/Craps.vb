﻿Public Class Craps

    Private steen1 As Dobbelsteen
    Private steen2 As Dobbelsteen
    Private pogingen As Integer
    Private som As Integer
    Private speelSom As Integer

    Private magain As Boolean
    Public Property again() As Boolean
        Get
            Return magain
        End Get
        Set(ByVal value As Boolean)
            magain = value
        End Set
    End Property

    Private mBericht As String
    Public Property Bericht() As String
        Get
            Return mBericht
        End Get
        Set(ByVal value As String)
            mBericht = value
        End Set
    End Property



    Public Sub New()
        steen1 = New Dobbelsteen()
        Threading.Thread.Sleep(3000)
        steen2 = New Dobbelsteen()
        pogingen = 0
        again = False
    End Sub


    ' 1 = win, 2 = verlies, 3 = speel opnieuw
    Public Function Play() As Integer

        Dim g1 As Integer = steen1.Gooi()
        Dim g2 As Integer = steen2.Gooi()
        som = g1 + g2
        Dim temp As Integer

        pogingen = pogingen + 1

        'eerste poging
        If pogingen = 1 Then
            speelSom = som
            temp = Poging1(som)
            Message(temp)
            Return temp

        Else
            temp = VolgendePogingen(som)
            Message(temp)
            Return temp
        End If

        Return 0
    End Function


    Private Function Poging1(som As Integer) As Integer
        If som = 7 Or som = 11 Then
            Return 1
        ElseIf som = 2 Or som = 3 Or som = 12 Then
            Return 2
        End If
        again = True
        Return 3
    End Function



    Private Function VolgendePogingen(som As Integer) As Integer
        again = False
        If som = 7 Then
            Return 2 'verlies

        ElseIf som = speelSom Then
            Return 1 ' win
        Else
            again = True
            Return 3
        End If
    End Function

    Private Function Message(win As Integer) As String

        Select Case win
            Case 1
                Bericht = "Win " & som
            Case 2
                Bericht = "Verlies" & som
            Case 3
                Bericht = "again" & som & "probeer eerste worp te behalen" & speelSom
            Case Else
                Bericht = "Foutje.."
        End Select

    End Function

End Class
