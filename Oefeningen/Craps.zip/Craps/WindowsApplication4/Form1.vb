﻿Public Class Form1

    Private craps As New Craps()
    Private craps2 As New Craps()


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        craps.Play()
        Button1.Enabled = craps.again
        Label1.Text = craps.Bericht

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        craps2.Play()
        Button2.Enabled = craps2.again
        Label2.Text = craps2.Bericht

    End Sub



End Class
