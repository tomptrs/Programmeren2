﻿Public Class Form1

    Private balloon As New Balloon()


    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()



    End Sub

    Private Sub PictureBox1_Paint(sender As Object, e As PaintEventArgs) Handles PictureBox1.Paint


        balloon.Display(e.Graphics)

    End Sub

    Dim i As Integer = 40
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        balloon.ChangeSize(100)
        ' refresh()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        balloon.MoveLeft()
        refresh()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        balloon.MoveRight()
        refresh()

    End Sub

    Private Sub refresh()
        PictureBox1.Refresh()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        balloon.ChangeColor()
    End Sub
End Class
