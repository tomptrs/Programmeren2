﻿Public Class Balloon

    Public x As Integer
    Public y As Integer
    Private diameter As Integer = 20
    Private pen As New Pen(Color.Black)




    Sub New()

    End Sub

    Public Sub MoveRight()
        x = x + 10
    End Sub

    Public Sub ChangeColor()
        pen.Color = Color.Red
    End Sub

    Public Sub MoveLeft()
        x = x - 10
    End Sub

    Public Sub ChangeSize(change As Integer)
        diameter = diameter + change


    End Sub




    Public Sub Display(drawArea As Graphics)
        drawArea.DrawEllipse(pen, x, y, diameter, diameter)

    End Sub
End Class
