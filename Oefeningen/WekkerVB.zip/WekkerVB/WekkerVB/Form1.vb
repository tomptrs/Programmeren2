﻿Public Class Form1

    Private wekker As New Wekker()

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        Timer1.Start()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick

        wekker.Refresh()

        If wekker.alarmOff = True Then
            My.Computer.Audio.PlaySystemSound(
        System.Media.SystemSounds.Asterisk)



        End If

        Label1.Text = wekker.huidigeTijd.TimeOfDay.ToString
    End Sub
End Class
