﻿Public Class Wekker

    Public huidigeTijd As DateTime

    Public alarm As DateTime

    Public alarmOff As Boolean


    Sub New()
        huidigeTijd = DateTime.Now
        alarm = huidigeTijd.AddMinutes(1)
        alarmOff = False
    End Sub



    Sub Refresh()

        huidigeTijd = DateTime.Now

        If huidigeTijd.Hour = alarm.Hour And huidigeTijd.Minute = alarm.Minute Then
            alarmOff = True
        End If

    End Sub


End Class
