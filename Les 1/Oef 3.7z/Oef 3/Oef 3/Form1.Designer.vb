﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmOef3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblNummer = New System.Windows.Forms.Label()
        Me.lblNaam = New System.Windows.Forms.Label()
        Me.txtNummer = New System.Windows.Forms.TextBox()
        Me.txtNaam = New System.Windows.Forms.TextBox()
        Me.btnRegister = New System.Windows.Forms.Button()
        Me.lbLogboek = New System.Windows.Forms.ListBox()
        Me.btnOpslaan = New System.Windows.Forms.Button()
        Me.btnZoek = New System.Windows.Forms.Button()
        Me.lblFilter = New System.Windows.Forms.Label()
        Me.txtFilter = New System.Windows.Forms.TextBox()
        Me.lbFilter = New System.Windows.Forms.ListBox()
        Me.SuspendLayout()
        '
        'lblNummer
        '
        Me.lblNummer.AutoSize = True
        Me.lblNummer.Location = New System.Drawing.Point(12, 9)
        Me.lblNummer.Name = "lblNummer"
        Me.lblNummer.Size = New System.Drawing.Size(99, 13)
        Me.lblNummer.TabIndex = 0
        Me.lblNummer.Text = "Personeelsnummer:"
        '
        'lblNaam
        '
        Me.lblNaam.AutoSize = True
        Me.lblNaam.Location = New System.Drawing.Point(12, 34)
        Me.lblNaam.Name = "lblNaam"
        Me.lblNaam.Size = New System.Drawing.Size(38, 13)
        Me.lblNaam.TabIndex = 1
        Me.lblNaam.Text = "Naam:"
        '
        'txtNummer
        '
        Me.txtNummer.Location = New System.Drawing.Point(117, 2)
        Me.txtNummer.Name = "txtNummer"
        Me.txtNummer.Size = New System.Drawing.Size(100, 20)
        Me.txtNummer.TabIndex = 3
        '
        'txtNaam
        '
        Me.txtNaam.Location = New System.Drawing.Point(117, 27)
        Me.txtNaam.Name = "txtNaam"
        Me.txtNaam.Size = New System.Drawing.Size(100, 20)
        Me.txtNaam.TabIndex = 4
        '
        'btnRegister
        '
        Me.btnRegister.Location = New System.Drawing.Point(53, 63)
        Me.btnRegister.Name = "btnRegister"
        Me.btnRegister.Size = New System.Drawing.Size(75, 23)
        Me.btnRegister.TabIndex = 5
        Me.btnRegister.Text = "Registreer"
        Me.btnRegister.UseVisualStyleBackColor = True
        '
        'lbLogboek
        '
        Me.lbLogboek.FormattingEnabled = True
        Me.lbLogboek.Location = New System.Drawing.Point(18, 105)
        Me.lbLogboek.Name = "lbLogboek"
        Me.lbLogboek.Size = New System.Drawing.Size(254, 147)
        Me.lbLogboek.TabIndex = 6
        Me.lbLogboek.TabStop = False
        '
        'btnOpslaan
        '
        Me.btnOpslaan.Location = New System.Drawing.Point(157, 63)
        Me.btnOpslaan.Name = "btnOpslaan"
        Me.btnOpslaan.Size = New System.Drawing.Size(75, 23)
        Me.btnOpslaan.TabIndex = 7
        Me.btnOpslaan.Text = "Opslaan"
        Me.btnOpslaan.UseVisualStyleBackColor = True
        '
        'btnZoek
        '
        Me.btnZoek.Location = New System.Drawing.Point(181, 306)
        Me.btnZoek.Name = "btnZoek"
        Me.btnZoek.Size = New System.Drawing.Size(75, 23)
        Me.btnZoek.TabIndex = 8
        Me.btnZoek.Text = "Zoek"
        Me.btnZoek.UseVisualStyleBackColor = True
        '
        'lblFilter
        '
        Me.lblFilter.AutoSize = True
        Me.lblFilter.Location = New System.Drawing.Point(15, 283)
        Me.lblFilter.Name = "lblFilter"
        Me.lblFilter.Size = New System.Drawing.Size(138, 13)
        Me.lblFilter.TabIndex = 9
        Me.lblFilter.Text = "Filter op personeelsnummer:"
        '
        'txtFilter
        '
        Me.txtFilter.Location = New System.Drawing.Point(156, 280)
        Me.txtFilter.Name = "txtFilter"
        Me.txtFilter.Size = New System.Drawing.Size(100, 20)
        Me.txtFilter.TabIndex = 10
        '
        'lbFilter
        '
        Me.lbFilter.FormattingEnabled = True
        Me.lbFilter.Location = New System.Drawing.Point(18, 338)
        Me.lbFilter.Name = "lbFilter"
        Me.lbFilter.Size = New System.Drawing.Size(254, 160)
        Me.lbFilter.TabIndex = 11
        '
        'frmOef3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(290, 513)
        Me.Controls.Add(Me.lbFilter)
        Me.Controls.Add(Me.txtFilter)
        Me.Controls.Add(Me.lblFilter)
        Me.Controls.Add(Me.btnZoek)
        Me.Controls.Add(Me.btnOpslaan)
        Me.Controls.Add(Me.lbLogboek)
        Me.Controls.Add(Me.btnRegister)
        Me.Controls.Add(Me.txtNaam)
        Me.Controls.Add(Me.txtNummer)
        Me.Controls.Add(Me.lblNaam)
        Me.Controls.Add(Me.lblNummer)
        Me.Name = "frmOef3"
        Me.Text = "Logboek"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblNummer As System.Windows.Forms.Label
    Friend WithEvents lblNaam As System.Windows.Forms.Label
    Friend WithEvents txtNummer As System.Windows.Forms.TextBox
    Friend WithEvents txtNaam As System.Windows.Forms.TextBox
    Friend WithEvents btnRegister As System.Windows.Forms.Button
    Friend WithEvents lbLogboek As System.Windows.Forms.ListBox
    Friend WithEvents btnOpslaan As System.Windows.Forms.Button
    Friend WithEvents btnZoek As System.Windows.Forms.Button
    Friend WithEvents lblFilter As System.Windows.Forms.Label
    Friend WithEvents txtFilter As System.Windows.Forms.TextBox
    Friend WithEvents lbFilter As System.Windows.Forms.ListBox

End Class
