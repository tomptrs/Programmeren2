﻿Public Class frmOef3

    Private Sub btnRegister_Click(sender As System.Object, e As System.EventArgs) Handles btnRegister.Click
        'Schrijven van een programma dat het in- en uitloggen van de werknemers bijhoudt in een logboek

        'Declareren van variabelen
        Dim naam As String
        Dim nummer As Integer
        Dim datum As Date

        'Uitlezen van de waardes
        naam = txtNaam.Text
        nummer = txtNummer.Text
        datum = Now

        'Bijhouden van het inloggen
        lbLogboek.Items.Add(CStr(nummer & "," & naam & "," & datum))
    End Sub

    Private Sub btnOpslaan_Click(sender As System.Object, e As System.EventArgs) Handles btnOpslaan.Click
        ' Wegschrijven van het logboek naar een sequentieel bestand
        Dim index As Integer

        FileOpen(1, "C:\Users\36949\Downloads\Logboek.txt", OpenMode.Output)
        For index = 0 To lbLogboek.Items.Count - 1
            PrintLine(1, lbLogboek.Items(index))
        Next

        FileClose(1)

    End Sub

    Private Sub btnZoek_Click(sender As System.Object, e As System.EventArgs) Handles btnZoek.Click
        'Filteren van logboek
        Dim filter As Integer
        Dim naam As String
        Dim nummer As Integer
        Dim datum As Date

        filter = txtFilter.Text

        FileOpen(1, "C:\Users\36949\Downloads\Logboek.txt", OpenMode.Input)
        For index = 0 To lbLogboek.Items.Count - 1
            Input(1, nummer)
            Input(1, naam)
            Input(1, datum)

            If nummer = filter Then
                lbFilter.Items.Add(CStr("Naam: " & naam & " \\ Datum: " & datum))
            End If
        Next

        FileClose(1)
    End Sub
End Class
